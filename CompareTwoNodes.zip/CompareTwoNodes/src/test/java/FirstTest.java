import base.BaseTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.openqa.selenium.WebDriver;
import server.TestServer;

import static java.lang.String.format;

public class FirstTest extends BaseTest {

    @RegisterExtension
    static TestServer server = new TestServer(FirstTest.class.getSimpleName());
    WebDriver driver;

    @BeforeEach
    public void init() {
        driver = getChromeDriver();
    }

    @Test
    public void verifyDom()
    {
        driver.get(format("http://localhost:%d", server.getPort()));
    }

    @AfterEach
    public void tearDown()
    {
        driver.quit();
    }
}
